# Evaluation report

This report is generated from the provided public sample by `python code/evaluation/main.py`. Exact row and sequence comparisons are against `dataset/sample_output.csv`; the 518-row evaluation set has no public answer key, so no hidden-set accuracy is claimed. The report distinguishes the public benchmark from our synthetic checks.

## Metrics

Measured on the 32 public sample cases after the latest run: status accuracy 29/32 (90.63%); exact-step accuracy 86/194 aligned steps (44.33%); field accuracy 675/1,164 aligned fields (58.00%); exact sequence accuracy 7/32 (21.88%); exact row accuracy 7/32 (21.88%). Field/step accuracy counts position-aligned slots and treats missing/extra steps as mismatches. The full 518-case set has no public answer key, so its accuracy is unknown. Reproduce these figures with `python code/evaluation/main.py`.

## Additional evaluation cases

1. A surname correction that explicitly preserves account data must return `NOT_APPLICABLE` with no steps.
2. A marketing-only opt-out that retains the account and service records must return `NOT_APPLICABLE` with no steps.
3. A direct account erasure request must be recognized as deletion intent.

All three run as synthetic assertions in the evaluation script.

## Failures found and improvements made

- Initial intent matching missed deletion requests phrased as “remove records” or “deleting my account”; intent patterns were broadened while explicit access, correction, login-reset, and marketing-only requests remain excluded.
- Treating a stable internal user reference as direct PII made permitted tombstones appear exposed; the code now separates direct identifiers from stable references and checks tombstones using the direct-identifier rule.
- Authorized cases with no supporting observations were initially marked complete with an empty checklist; the status now remains incomplete unless evidence supports verification.
- Future verification steps on incomplete cases initially carried old evidence citations; those citations are now blank as required.
- An unfiltered null value from structured logs linked unrelated records to every subject; null placeholders are now excluded during identity expansion.
- Historical resource matches are carried to the latest observation for the same resource so redacted or anonymized current records can be verified.
- Evidence after `audit_at` is excluded, and activity results remain contextual claims rather than state proof.

The public-sample exact-row score remains limited (7/32); the largest remaining problems are identity-to-record linkage where evidence has no direct matching identifier and incomplete reconstruction of records represented in specialized business artifacts. This remains a material limitation of the current predictions. Synthetic test coverage supplements but does not replace evidence-based accuracy.

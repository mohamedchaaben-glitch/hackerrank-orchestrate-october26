# Ghost Data Still Exists - deletion audit agent

## Run

From the repository root, use Python 3.10+:

```bash
python code/main.py
```

The program reads `dataset/` and writes the sorted `output.csv` at the repository root. It builds a time-bounded evidence index from the manifest, JSON records, SQLite-compatible SQL snapshots, and logs; extracts text from PDFs when `pypdf` is installed; and attempts screenshot OCR when Pillow, `pytesseract`, and the Tesseract executable are available. OCR/text extraction failures are skipped safely. Install the optional document/OCR packages with `pip install -r code/requirements.txt`; Tesseract itself must be installed separately for image OCR.

## Evaluation

Run the public sample and three synthetic intent checks with:

```bash
python code/evaluation/main.py
```

The deterministic implementation applies `deletion_rules.csv`, resolves current and historic identifiers, filters each observation to `audit_at`, and emits ordered findings, remediation actions, and verification steps. Operational activity results are treated as claims rather than proof. No remote model or API key is required.

# Token and cost usage report

Final full-dataset run: `python code/main.py`, processing all 518 requests.

- Model provider/name: none (local deterministic Python evidence and policy pipeline)
- Model calls: 0
- Input tokens: 0
- Output tokens: 0
- Total tokens: 0; average: 0 per request
- Estimated model cost: $0.00 total; $0.00 per request

The runtime reads local CSV, JSON, SQL, log, and available document/media evidence. It does not send data to an external model provider. Optional PDF/OCR libraries, when installed, run locally.

"""Public-sample and synthetic evaluation workflow for the deletion auditor."""
import csv, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
ROOT=HERE.parent
sys.path.insert(0,str(HERE))
import main as agent


def evaluate():
    agent.RULES={r['data_category']:r['required_action'] for r in csv.DictReader((agent.DATA/'deletion_rules.csv').open(encoding='utf-8-sig'))}
    agent.OBS.clear(); agent.load_evidence()
    aliases,by_email=agent.load_identities(); ctx={'aliases':aliases,'by_email':by_email}
    gold={r['case_id']:r for r in csv.DictReader((agent.DATA/'sample_output.csv').open(encoding='utf-8-sig'))}
    samples=list(csv.DictReader((agent.DATA/'sample_deletion_requests.csv').open(encoding='utf-8-sig')))
    status_ok=exact=fields_ok=fields_total=step_ok=step_total=seq_ok=0
    for case in samples:
        status,steps=agent.build_case(case,ctx,agent.OBS); expected=gold[case['case_id']]
        gold_steps=json.loads(expected['steps_json']); status_ok+=status==expected['deletion_status']
        fields=('phase','system_id','resource_id','operation','state','evidence_id')
        for i in range(max(len(steps),len(gold_steps))):
            step_total+=1
            if i<len(steps) and i<len(gold_steps) and all(steps[i].get(f)==gold_steps[i].get(f) for f in fields): step_ok+=1
            for f in fields:
                fields_total+=1
                if i<len(steps) and i<len(gold_steps) and steps[i].get(f)==gold_steps[i].get(f): fields_ok+=1
        seq=lambda xs:[(x.get('phase'),x.get('system_id'),x.get('resource_id'),x.get('operation'),x.get('state'),x.get('evidence_id')) for x in xs]
        seq_ok+=seq(steps)==seq(gold_steps)
        exact+=status==expected['deletion_status'] and seq(steps)==seq(gold_steps)
    # Synthetic cases exercise policy and ordering logic without challenge labels or evidence IDs.
    custom=[]
    custom.append(('correction-not-deletion',not agent.deletion_intent('Please correct my surname without deleting or removing any account data.')))
    custom.append(('marketing-opt-out-only',not agent.deletion_intent('Remove me from marketing lists only; keep my account and service records.')))
    custom.append(('deletion-language',agent.deletion_intent('I request erasure of my account and personal data.')))
    print(f'public sample cases: {len(samples)}')
    print(f'status accuracy: {status_ok}/{len(samples)} = {status_ok/len(samples):.4f}')
    print(f'step accuracy (aligned step slots): {step_ok}/{step_total} = {step_ok/step_total:.4f}')
    print(f'field accuracy (aligned step slots): {fields_ok}/{fields_total} = {fields_ok/fields_total:.4f}')
    print(f'sequence accuracy: {seq_ok}/{len(samples)} = {seq_ok/len(samples):.4f}')
    print(f'exact row accuracy: {exact}/{len(samples)} = {exact/len(samples):.4f}')
    print('custom cases:')
    for name,passed in custom: print(f'  {name}: {"PASS" if passed else "FAIL"}')
    if not all(ok for _,ok in custom): raise SystemExit(1)

if __name__=='__main__': evaluate()

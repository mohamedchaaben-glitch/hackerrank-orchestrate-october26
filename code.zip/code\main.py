import csv, json, hashlib, re, sqlite3, sys, shutil
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'dataset'
MANIFEST = {x['file_path']: x for x in csv.DictReader((DATA/'evidence_files.csv').open(encoding='utf-8-sig'))}
OBS = []
RULES = {}
VALUE_INDEX = defaultdict(list)
RESOURCE_INDEX = defaultdict(list)


def dt(s):
    if not s: return ''
    try: return datetime.fromisoformat(str(s).replace('Z','+00:00')).astimezone(timezone.utc).isoformat()
    except Exception: return ''

def norm(s): return re.sub(r'[^a-z0-9@.+]', '', str(s).casefold())
def values(x):
    if isinstance(x, dict):
        for k,v in x.items():
            if isinstance(v,(dict,list)): yield from values(v)
            elif v is not None: yield str(v)
    elif isinstance(x,list):
        for v in x: yield from values(v)
    elif x is not None: yield str(x)

def add(file_id, path, time, system, collection, obj, evidence_id=None):
    if not isinstance(obj,dict): return
    resource = obj.get('resource_id') or obj.get('id')
    if not resource: return
    system=str(system or obj.get('system_id') or '')
    # Normalize physical SQL table names into the logical service identifiers used in policy output.
    for token,logical in [('customer_profiles','account_service'),('customer_accounts','account_service'),('customer_search','search_service'),('analytics','analytics_platform'),('backup','backup_service'),('support','support_platform'),('export','export_service'),('security','security_service'),('identity','identity_service'),('connector','integration_service'),('marketing','marketing_platform')]:
        if token in system.casefold(): system=logical; break
    try: rel=Path(path).relative_to(DATA).as_posix()
    except Exception: rel=''
    file_time=dt(MANIFEST.get(rel,{}).get('captured_at'))
    OBS.append({'time':dt(time),'file_time':file_time,'system':system, 'collection':str(collection or obj.get('data_category') or obj.get('record_type') or ''), 'resource':str(resource), 'obj':obj, 'evidence': evidence_id or file_id, 'path':path})

def parse_json(path, fid, manifest_time):
    try: data=json.loads(path.read_text(encoding='utf-8-sig'))
    except Exception: return
    if isinstance(data,dict) and isinstance(data.get('snapshots'),list):
        for snap in data['snapshots']:
            for rec in snap.get('records',[]): add(fid,str(path),snap.get('captured_at') or data.get('exported_at') or manifest_time,snap.get('data_store'),snap.get('collection'),rec)
    elif isinstance(data,dict) and isinstance(data.get('records'),list):
        sysid=data.get('system_id') or data.get('data_store') or data.get('source') or data.get('origin') or ''
        coll=data.get('collection') or ''
        t=data.get('captured_at') or data.get('exported_at') or manifest_time
        for rec in data['records']: add(fid,str(path),rec.get('observed_at') or rec.get('updated_at') or rec.get('captured_at') or t,rec.get('system_id') or sysid,rec.get('data_category') or coll,rec)
    else:
        def walk(x,sysid='',coll='',t=''):
            if isinstance(x,dict):
                if x.get('resource_id'):
                    add(fid,str(path),x.get('observed_at') or x.get('updated_at') or x.get('captured_at') or t,x.get('system_id') or sysid,x.get('data_category') or x.get('collection') or coll,x)
                for k,v in x.items():
                    if not isinstance(v,(dict,list)): continue
                    if k in ('account_service','search_service','analytics_platform','support_platform','backup_service','integration_service','security_service','export_service','marketing_platform','identity_service'):
                        walk(v,k,'',t)
                    else:
                        walk(v,sysid,k if k not in ('service_exports',) else coll,t)
            elif isinstance(x,list):
                for v in x: walk(v,sysid,coll,t)
        walk(data,t=data.get('exported_at') or data.get('captured_at') or manifest_time)


def parse_sql(path,fid,manifest_time):
    try:
        con=sqlite3.connect(':memory:'); con.executescript(path.read_text(encoding='utf-8-sig',errors='replace'))
        for (table,) in con.execute("select name from sqlite_master where type='table'"):
            cols=[r[1] for r in con.execute(f'pragma table_info("{table}")')]
            for row in con.execute(f'select * from "{table}"'):
                d=dict(zip(cols,row)); raw=d.get('record_json')
                if raw:
                    try: obj=json.loads(raw)
                    except: obj={}
                else: obj=d
                add(fid,str(path),d.get('updated_at') or manifest_time,d.get('origin_system') or table,d.get('collection_name') or table,obj)
        con.close()
    except Exception: pass

def parse_log(path,fid,manifest_time):
    # Join start/completion lines with a shared trace id before indexing resource state.
    kv=re.compile(r'([A-Za-z_][A-Za-z0-9_]*)=(?:"([^"]*)"|([^\s]+))')
    parsed=[]; contexts=defaultdict(dict)
    for line in path.read_text(encoding='utf-8-sig',errors='replace').splitlines():
        tm=re.match(r'^(\S+)',line); t=tm.group(1) if tm else manifest_time
        d={m.group(1):m.group(2) if m.group(2) is not None else m.group(3) for m in kv.finditer(line)}
        if 'resource_id' not in d:
            rid=re.search(r'\b((?:account|search|support|analytics|backup|export|audit_record|marketing|data_flow|cache|attachment|delivery|order|profile|event|archive|ticket|tombstone)_[0-9][A-Za-z0-9-]*)\b',line)
            if rid: d['resource_id']=rid.group(1)
        d['_line']=line.strip(); d['_event']=d.get('event','')
        trace=d.get('trace_id') or d.get('requestId')
        if trace:
            # Keep lookup keys and subject refs, not volatile result fields, as trace context.
            for k,v in d.items():
                if k in ('lookup_key','subject_key','subject_ref','subject_reference','customer_email','customer_reference','requester_email','requester_name','requester_phone','email','phone','email_hash') and str(v).casefold() not in ('null','none','false',''):
                    contexts[trace][k]=v
        parsed.append((t,d,trace))
    for t,d,trace in parsed:
        if 'resource_id' not in d: continue
        if trace:
            for k,v in contexts[trace].items(): d.setdefault(k,v)
        event=d.get('event','')
        if any(w in event.lower() for w in ('lookup','read_completed','query_completed','scan','connector','restore','record','profile','index','heartbeat')) or d.get('rows')=='0' or d.get('result') in ('hit','miss'):
            add(fid,str(path),t,d.get('service') or d.get('function') or '',event,d)


def load_evidence():
    OBS.clear(); VALUE_INDEX.clear(); RESOURCE_INDEX.clear()
    for rel,m in MANIFEST.items():
        p=DATA/rel; fid=m['file_id']; t=m['captured_at']
        if not p.exists(): continue
        if p.suffix.lower()=='.json': parse_json(p,fid,t)
        elif p.suffix.lower()=='.sql': parse_sql(p,fid,t)
        elif p.suffix.lower()=='.log': parse_log(p,fid,t)
        elif p.suffix.lower()=='.pdf':
            # Text-layer extraction reads supplied business records when available.
            try:
                from pypdf import PdfReader
                txt='\n'.join(pg.extract_text() or '' for pg in PdfReader(str(p)).pages)
                parse_text_records(txt,fid,p,t)
            except Exception: pass
        elif p.suffix.lower() in ('.png','.jpg','.jpeg','.tif','.tiff'):
            # Optional OCR reads screenshots when Pillow, pytesseract, and Tesseract are installed.
            try:
                from PIL import Image
                import pytesseract
                txt=pytesseract.image_to_string(Image.open(p))
                parse_text_records(txt,fid,p,t)
            except Exception: pass
    # Build inverted indexes once so each request searches only observations sharing an identifier.
    for obs in OBS:
        RESOURCE_INDEX[obs['resource']].append(obs)
        vals=[v for k,v in obs['obj'].items() if k!='_line' and not isinstance(v,(dict,list)) and v is not None]
        vals += re.findall(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}',str(obs['obj'].get('_line','')),re.I)
        vals += re.findall(r'\+?\d[\d ()-]{6,}\d',str(obs['obj'].get('_line','')))
        seen=set()
        for val in vals:
            nv=norm(val)
            if nv and nv not in ('null','none','false') and nv not in seen:
                VALUE_INDEX[nv].append(obs); seen.add(nv)

def parse_text_records(txt,fid,path,t):
    # Extract every explicit resource reference from text-layer PDFs or OCR output.
    labels={}
    for line in txt.splitlines():
        m=re.match(r'\s*([A-Za-z_][\w ]{1,35})\s*[:=]\s*(.*?)\s*$',line)
        if m: labels[m.group(1).strip().lower().replace(' ','_')]=m.group(2).strip()
    ids=list(dict.fromkeys(re.findall(r'\b(?:account|search|support|analytics|backup|export|audit_record|marketing|data_flow|cache|attachment|delivery|order|profile|event|archive|ticket|tombstone)_[0-9][A-Za-z0-9-]*\b',txt,re.I)))
    rid=next((v for k,v in labels.items() if k in ('resource_id','record_id','attachment_id')),None) or (ids[0] if ids else None)
    if not rid: return
    prefix=rid.split('_',1)[0].casefold()
    system={'account':'account_service','search':'search_service','support':'support_platform','analytics':'analytics_platform','backup':'backup_service','export':'export_service','audit':'security_service','marketing':'marketing_platform','data':'integration_service','tombstone':'identity_service'}.get(prefix,'')
    low=txt.casefold()
    coll='ticket_attachments' if 'attachment' in low or 'attached file' in low else ('support_conversations' if prefix=='support' else '')
    obj={'resource_id':rid,'_line':txt,'text':txt,**labels}
    add(fid,str(path),t,system,coll,obj)


def load_identities():
    current=defaultdict(set); by_email=defaultdict(set)
    for r in csv.DictReader((DATA/'user_identities.csv').open(encoding='utf-8-sig')):
        uid=r['user_id']; current[uid].add(uid)
        for k in ('name','email','phone','email_hash'):
            if r.get(k): current[uid].add(r[k]);
        if r.get('email'): by_email[norm(r['email'])].add(uid)
    for r in csv.DictReader((DATA/'user_audit_log.csv').open(encoding='utf-8-sig')):
        uid=r['user_id']; current[uid].add(uid)
        for k in ('old_value','new_value'):
            v=r.get(k,'')
            if v: current[uid].add(v)
        if r.get('field_name')=='email':
            if r.get('old_value'): by_email[norm(r['old_value'])].add(uid)
            if r.get('new_value'): by_email[norm(r['new_value'])].add(uid)
    # Email hashes are also historical/current aliases, including common SHA-256 form.
    for uid,als in current.items():
        for v in list(als):
            if '@' in v: als.add(hashlib.sha256(v.strip().lower().encode()).hexdigest())
    return current,by_email


def deletion_intent(text):
    s=text.casefold()
    negative=['do not delete','don’t delete','dont delete','not a request to erase','please don\'t delete','still want receipts','information request','resetting the login','correct it without removing','marketing lists only','copy of the information','access request','not a request to delete','without deleting','without removing']
    if any(x in s for x in negative): return False
    terms=['delet','erase','eras','remove my account','remove the account','remove the profile','remove records','remove that search result','remove my personal data','erasure','effacer','effacement','削除','삭제','close the account','close my account','close this account','would like it closed','account closure','permanent account','suppression','supprimer','supprimer mon compte','suppression définitive','eliminar','eliminación','borrar','dar de baja','löschung','löschen','cancellare','eliminare','apagar mi cuenta']
    if any(x in s for x in terms): return True
    if 'remove' in s and any(x in s for x in ('account','profile','personal data','records','search result')): return True
    # A request to confirm that an already-submitted deletion succeeded is also in scope.
    return any(x in s for x in ('confirm','check','verify','latest state')) and any(x in s for x in ('profile is gone','account is gone','profile has been deleted','account has been deleted','remaining records cannot identify','no longer exists'))


def category(o):
    sysid=o['system'].casefold(); coll=o['collection'].casefold(); obj=o['obj']; blob=' '.join([sysid,coll,str(obj.get('data_category','')),str(obj.get('record_type',''))]).casefold()
    if 'tombstone' in blob or 'deleted_customer_references' in blob: return 'ACCOUNT_TOMBSTONE'
    if 'connector' in blob or obj.get('enabled') is not None and 'data_flow' in str(obj.get('resource_id','')): return 'DATA_FLOW'
    if 'backup' in blob or 'archive' in blob: return 'BACKUP_ARCHIVE'
    if 'security' in blob or 'audit_record' in str(obj.get('resource_id','')): return 'SECURITY_AUDIT_LOG'
    if 'legal' in blob or 'retained_order' in blob or 'order_record' in blob: return 'LEGAL_HOLD_RECORD'
    if 'attachment' in blob: return 'SUPPORT_ATTACHMENT'
    if 'support' in blob or 'conversation' in blob or 'ticket' in blob: return 'SUPPORT_MESSAGE'
    if 'search' in blob or 'index' in blob: return 'SEARCH_INDEX_ENTRY'
    if 'cache' in blob: return 'CACHE_ENTRY'
    if 'analytics' in blob or 'report' in blob: return 'ANALYTICS_PROFILE'
    if 'telemetry' in blob: return 'PRODUCT_TELEMETRY'
    if 'export' in blob: return 'USER_EXPORT'
    if 'marketing' in blob or 'audience' in blob: return 'MARKETING_PROFILE'
    if 'email' in blob and ('delivery' in blob or 'notification' in blob): return 'EMAIL_DELIVERY_LOG'
    if 'account' in blob or 'profile' in blob: return 'USER_PROFILE'
    return str(obj.get('data_category') or 'SECONDARY_IDENTIFIER').upper()

OP_RANK={'REPORT_REMAINING_RECORD':0,'REPORT_EXPOSED_PII':1,'REPORT_ACTIVE_DATA_FLOW':2,'REPORT_RESTORE_RISK':3,'DISABLE_DATA_FLOW':0,'BLOCK_RESTORE':1,'DELETE_RECORD':2,'REDACT_RECORD':3,'ANONYMIZE_RECORD':4,'VERIFY_RECORD_ABSENT':0,'VERIFY_RECORD_PRESENT':1,'VERIFY_RECORD_REDACTED':2,'VERIFY_RECORD_ANONYMIZED':3,'VERIFY_DATA_FLOW_DISABLED':4,'VERIFY_RESTORE_BLOCKED':5}
def step(phase,system,resource,op,state,evidence=''):
    return {'phase':phase,'system_id':system,'resource_id':resource,'operation':op,'state':state,'evidence_id':evidence}
def pii_present(o, aliases):
    obj=o['obj']; keys={'email','owner_email','requester_email','customer_email','phone','requester_phone','full_name','name','display_name','email_hash','correlation_key','lookup_key','subject_key','subject_selector'}
    for k,v in obj.items():
        if k in keys and v not in (None,'','null','false','False'):
            nv=norm(v)
            if any(norm(a)==nv for a in aliases if a): return True
    # For logs, a matched email/phone is direct PII even if only present in the line body.
    return any(norm(a) and norm(a) in norm(str(obj.get('_line',''))) for a in aliases if '@' in a or re.search(r'\d{7,}',a))

def build_case(case, aliases_by_user, all_obs):
    if not deletion_intent(case['request_text']): return 'NOT_APPLICABLE',[]
    email=norm(case['email']); candidates=aliases_by_user.get('by_email',{}).get(email,set())
    # Resolve by the request email and current/history tables; the supplied email itself
    # remains a valid search key even when the identity snapshot is incomplete.
    uid=sorted(candidates)[0] if candidates else None
    aliases=set(aliases_by_user['aliases'].get(uid,set()) if uid else ()) | {case['email']}
    cutoff=dt(case['audit_at'])
    # Expand identity through stable references in any exact request-email evidence.
    for o in VALUE_INDEX.get(norm(case['email']),[]):
        if o['time'] and o['time']<=cutoff:
            for k,v in o['obj'].items():
                if k in ('user_id','customer_reference','subject_reference','subject_ref') and v and str(v).casefold() not in ('null','none','false','') : aliases.add(str(v))
    # Retrieve only records that carry one of the resolved identifiers.
    found={}
    for alias in aliases:
        key=norm(alias)
        if not key: continue
        for o in VALUE_INDEX.get(key,[]):
            if o['time'] and o['time']<=cutoff and o.get('file_time') and o['file_time']<=cutoff: found[id(o)]=o
    match=list(found.values())
    # Group repeated snapshots by resource; the newest observation is the best state at the cutoff.
    groups=defaultdict(list)
    for o in match: groups[o['resource']].append(o)
    current=[]
    for rid,obs in groups.items():
        # Carry identity linkage forward to later snapshots even when PII is already scrubbed.
        obs=[x for x in RESOURCE_INDEX.get(rid,[]) if x['time'] and x['time']<=cutoff and x.get('file_time') and x['file_time']<=cutoff] or obs
        obs.sort(key=lambda x:x['time']); last=obs[-1]
        # A later readback can prove absence; handle it as a separate terminal state.
        if last['obj'].get('rows')=='0' or str(last['obj'].get('http_status'))=='404' or str(last['obj'].get('status_code'))=='404' or last['obj'].get('result')=='miss':
            current.append((last,'ABSENT',category(last))); continue
        current.append((last,'PRESENT',category(last)))
    findings=[]; fixes=[]; checks=[]
    # Additional activity rows can establish enabled data paths when the configuration is not in a snapshot.
    for o,state,cat in current:
        obj=o['obj']; rid=o['resource']; system=o['system'] or cat.lower()
        if cat=='DATA_FLOW':
            enabled=str(obj.get('enabled','')).lower() in ('true','1','yes','enabled')
            if enabled:
                findings.append(step('FINDING',system,rid,'REPORT_ACTIVE_DATA_FLOW','ACTIVE',o['evidence']))
                fixes.append(step('REMEDIATION',system,rid,'DISABLE_DATA_FLOW','DISABLED'))
                checks.append(step('VERIFICATION',system,rid,'VERIFY_DATA_FLOW_DISABLED','DISABLED'))
            continue
        if cat=='BACKUP_ARCHIVE':
            allowed=obj.get('restore_allowed',obj.get('restore_enabled'))
            restore=str(allowed).lower() in ('true','1','yes','enabled') or (str(obj.get('eligible','')).lower()=='true' and str(obj.get('deletion_block','')).lower() in ('false','0'))
            if restore:
                findings.append(step('FINDING',system,rid,'REPORT_RESTORE_RISK','ACTIVE',o['evidence']))
                fixes.append(step('REMEDIATION',system,rid,'BLOCK_RESTORE','BLOCKED'))
                checks.append(step('VERIFICATION',system,rid,'VERIFY_RESTORE_BLOCKED','BLOCKED'))
            else:
                checks.append(step('VERIFICATION',system,rid,'VERIFY_RESTORE_BLOCKED','BLOCKED',o['evidence']))
            continue
        if state=='ABSENT':
            checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_ABSENT','ABSENT',o['evidence'])); continue
        # Determine policy action and whether identifying values remain.
        exposed=pii_present(o,aliases)
        action=None
        if cat in ('USER_PROFILE','SECONDARY_IDENTIFIER','SEARCH_INDEX_ENTRY','CACHE_ENTRY','USER_EXPORT','MARKETING_PROFILE'):
            action=RULES.get(cat,'DELETE')
        elif cat=='SUPPORT_ATTACHMENT':
            owner=str(obj.get('owner_reference') or obj.get('subject_reference') or obj.get('customer_reference') or '')
            action='DELETE' if owner==uid or exposed else 'RETAIN'
        elif cat in ('SUPPORT_MESSAGE','EMAIL_DELIVERY_LOG','ACCOUNT_TOMBSTONE'):
            action=RULES.get(cat,'REDACT')
        elif cat in ('ANALYTICS_PROFILE','PRODUCT_TELEMETRY'):
            action=RULES.get(cat,'ANONYMIZE')
        elif cat=='SECURITY_AUDIT_LOG': action=RULES.get(cat,'RETAIN')
        elif cat=='LEGAL_HOLD_RECORD': action=RULES.get(cat,'RETAIN')
        else:
            action='DELETE'
        if action=='DELETE':
            findings.append(step('FINDING',system,rid,'REPORT_REMAINING_RECORD','PRESENT',o['evidence']))
            fixes.append(step('REMEDIATION',system,rid,'DELETE_RECORD','ABSENT'))
            checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_ABSENT','ABSENT'))
        elif action=='REDACT' and exposed:
            findings.append(step('FINDING',system,rid,'REPORT_EXPOSED_PII','PRESENT',o['evidence']))
            fixes.append(step('REMEDIATION',system,rid,'REDACT_RECORD','REDACTED'))
            checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_REDACTED','REDACTED'))
        elif action=='ANONYMIZE' and (any(obj.get(k) not in (None,'','null') for k in ('user_id','customer_reference','subject_reference','email','phone','email_hash','correlation_key','lookup_key')) or pii_present(o,aliases)):
            findings.append(step('FINDING',system,rid,'REPORT_EXPOSED_PII','PRESENT',o['evidence']))
            fixes.append(step('REMEDIATION',system,rid,'ANONYMIZE_RECORD','ANONYMIZED'))
            checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_ANONYMIZED','ANONYMIZED'))
        elif action=='ANONYMIZE':
            checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_ANONYMIZED','ANONYMIZED',o['evidence']))
        elif action=='REDACT':
            checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_REDACTED','REDACTED',o['evidence']))
        else:
            op='VERIFY_RECORD_PRESENT'
            state0='PRESENT'
            if cat=='ACCOUNT_TOMBSTONE' and exposed:
                findings.append(step('FINDING',system,rid,'REPORT_EXPOSED_PII','PRESENT',o['evidence']))
                fixes.append(step('REMEDIATION',system,rid,'REDACT_RECORD','REDACTED'))
                checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_REDACTED','REDACTED'))
            elif cat in ('SUPPORT_MESSAGE','EMAIL_DELIVERY_LOG','ACCOUNT_TOMBSTONE'):
                checks.append(step('VERIFICATION',system,rid,'VERIFY_RECORD_REDACTED','REDACTED',o['evidence']))
            else: checks.append(step('VERIFICATION',system,rid,op,state0,o['evidence']))
    # A full account failover SQL snapshot can prove the absence of a canonical padded
    # account id when its user_id/resource_id pairs establish that naming convention.
    has_account_state=any(x['system_id']=='account_service' for x in findings+checks)
    uid_match=re.fullmatch(r'user_(\d{2})',uid or '')
    if not has_account_state and uid_match:
        canonical=f"account_{int(uid_match.group(1)):03d}"
        anchors=[]
        for obs in all_obs:
            if 'customer_accounts_failover_replica' not in obs['path'].casefold(): continue
            if not obs.get('file_time') or obs['file_time']>cutoff: continue
            ref=str(obs['obj'].get('user_id',''))
            rid=str(obs['resource'])
            if re.fullmatch(r'user_(\d{2})',ref) and rid==f"account_{int(ref[-2:]):03d}": anchors.append(obs)
        if anchors and not any(obs['resource']==canonical for obs in all_obs if obs.get('file_time') and obs['file_time']<=cutoff and 'customer_accounts_failover_replica' in obs['path'].casefold()):
            latest=max(anchors,key=lambda x:x['file_time'])
            checks.append(step('VERIFICATION','account_service',canonical,'VERIFY_RECORD_ABSENT','ABSENT',latest['evidence']))
    # Remove duplicate same-system/resource/operation evidence and avoid conflicted present-vs-absent checks.
    def unique(xs):
        got={}
        for x in xs: got[(x['system_id'],x['resource_id'],x['operation'])]=x
        return list(got.values())
    findings=unique(findings); fixes=unique(fixes); checks=unique(checks)
    # If any remediation is required, plans are future tense; include all supported fixes and post-fix checks.
    findings.sort(key=lambda x:(OP_RANK[x['operation']],x['system_id'],x['resource_id']))
    fixes.sort(key=lambda x:(OP_RANK[x['operation']],x['system_id'],x['resource_id']))
    checks.sort(key=lambda x:(OP_RANK[x['operation']],x['system_id'],x['resource_id']))
    status='INCOMPLETE' if findings or not checks else 'COMPLETE'
    if status=='INCOMPLETE':
        steps=findings+fixes+checks
        # Every planned verification step is future work, even for retained records.
        for item in steps:
            if item['phase']!='FINDING': item['evidence_id']=''
    else:
        # No findings means all record/process observations are compliant; cite only checks.
        steps=checks
    for i,s in enumerate(steps,1): s['step_no']=i
    return status,steps

def main():
    global RULES
    RULES={r['data_category']:r['required_action'] for r in csv.DictReader((DATA/'deletion_rules.csv').open(encoding='utf-8-sig'))}
    # Read the operational ledger as context; reported results are not treated as state proof.
    activity=list(csv.DictReader((DATA/'system_activity.csv').open(encoding='utf-8-sig')))
    load_evidence()
    aliases,by_email=load_identities()
    requests=list(csv.DictReader((DATA/'deletion_requests.csv').open(encoding='utf-8-sig')))
    rows=[]
    for c in requests:
        status,steps=build_case(c,{'aliases':aliases,'by_email':by_email},OBS)
        rows.append({'case_id':c['case_id'],'deletion_status':status,'steps_json':json.dumps(steps,ensure_ascii=False,separators=(',',':'))})
    rows.sort(key=lambda x:x['case_id'])
    out=ROOT/'output.csv'
    with out.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['case_id','deletion_status','steps_json']); w.writeheader(); w.writerows(rows)
    print(f'wrote {len(rows)} rows to {out}')
if __name__=='__main__': main()
